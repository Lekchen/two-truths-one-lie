
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/game.ts
import { getStore } from "@netlify/blobs";

// lib/game.mjs
var fail = (m) => {
  throw Error(m);
};
var uid = () => crypto.randomUUID();
var shuffle = (a) => {
  a = [...a];
  for (let i = a.length - 1; i > 0; i--) {
    const v = new Uint32Array(1);
    crypto.getRandomValues(v);
    let j = v[0] % (i + 1);
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
};
var active = (r) => r.members.filter((p) => p.role === "player" && p.score > 0);
var connected = (p, n) => !p.left && n - p.seen < 2e4;
var manager = (r, p) => p.id === r.host || p.id === r.cohost;
var safeName = (s) => typeof s === "string" && s.trim().length > 0 && s.trim().length <= 24;
var stat = () => ({ correct: 0, wrong: 0, skipped: 0, missed: 0, correctMs: 0 });
function member(name, role, n) {
  return { id: uid(), secret: uid() + uid(), name: name.trim(), role, score: 0, ready: false, away: false, awayRounds: 0, seen: n, skips: 0, stats: stat(), muted: false };
}
function createRoom(name, role = "player", n = Date.now()) {
  if (!safeName(name)) fail("Enter a nickname of 1\u201324 characters.");
  if (!["player", "viewer"].includes(role)) fail("Invalid role.");
  const p = member(name, role, n), a = new Uint32Array(1);
  crypto.getRandomValues(a);
  return { code: a[0].toString(36).padStart(6, "0").slice(-6).toUpperCase(), host: p.id, cohost: null, members: [p], phase: "lobby", settings: { points: 3, guessSeconds: 30 }, round: 0, manualLock: false, chat: [], reactions: [], order: [], cursor: 0, turnId: 0, author: null, votes: {}, orders: {}, statements: [], results: [], notice: "", deadline: null };
}
function assignHost(r, n) {
  const h = r.members.find((p) => p.id === r.host);
  if (h && connected(h, n)) return;
  if (h && !h.left && n - h.seen < 3e4) return;
  const candidates = r.members.filter((p) => connected(p, n));
  const next2 = candidates.find((p) => p.id === r.cohost) || candidates[0];
  if (next2) {
    r.host = next2.id;
    if (r.cohost === next2.id) r.cohost = null;
    r.notice = next2.name + " is now the host.";
  }
}
function win(r) {
  if (["lobby", "finished"].includes(r.phase)) return false;
  const a = active(r);
  if (a.length <= 1) {
    r.phase = "finished";
    r.winner = a[0]?.id ?? null;
    r.deadline = null;
    return true;
  }
  return false;
}
function resetSkips(r) {
  for (const p of active(r)) p.skips = p.score >= 6 ? 2 : 1;
}
function roundBegin(r, n) {
  r.round++;
  r.order = active(r).map((p) => p.id);
  r.cursor = -1;
  resetSkips(r);
  for (const p of [...active(r)]) {
    if (p.away) {
      p.awayRounds++;
      if (p.awayRounds > 3) {
        if (r.members.filter((m) => m.role === "viewer").length < 2) {
          p.role = "viewer";
          p.ready = false;
          r.notice = p.name + " moved to viewers after four away rounds.";
        } else remove(r, p, n, "Removed after four away rounds.");
      }
    } else p.awayRounds = 0;
  }
  if (win(r)) return;
  next(r, n);
}
function next(r, n) {
  if (win(r)) return;
  r.cursor++;
  while (r.cursor < r.order.length) {
    const p = r.members.find((p2) => p2.id === r.order[r.cursor]);
    if (p && p.role === "player" && p.score > 0 && !p.away) {
      r.author = p.id;
      r.turnId++;
      r.phase = "write";
      r.deadline = n + 9e4;
      r.extended = false;
      r.statements = [];
      r.orders = {};
      r.votes = {};
      r.results = [];
      r.reactions = [];
      return;
    }
    r.cursor++;
  }
  r.phase = "roundEnd";
  r.author = null;
  r.deadline = null;
}
function reveal(r, n) {
  if (r.phase !== "guess") return;
  r.results = [];
  for (const id of r.eligible) {
    const p = r.members.find((p2) => p2.id === id);
    if (!p || p.role !== "player" || p.score <= 0) continue;
    const v = r.votes[id];
    let delta = 0, type;
    if (v === void 0 || v.choice === null) {
      type = v === void 0 ? "missed" : "skipped";
      if (p.skips > 0) p.skips--;
      else delta = -1;
      p.stats[type]++;
    } else if (v.choice === 2) {
      delta = 1;
      type = "correct";
      p.stats.correct++;
      p.stats.correctMs += v.ms;
    } else {
      delta = -1;
      type = "wrong";
      p.stats.wrong++;
    }
    p.score = Math.max(0, p.score + delta);
    r.results.push({ id, choice: v?.choice ?? null, type, delta });
  }
  r.phase = "reveal";
  r.deadline = null;
  win(r);
}
function complete(r, n) {
  if (r.phase === "guess" && r.eligible.every((id) => Object.hasOwn(r.votes, id) || !r.members.some((p) => p.id === id))) reveal(r, n);
}
function remove(r, p, n, reason) {
  r.members = r.members.filter((x) => x.id !== p.id);
  r.chat.push({ id: uid(), system: true, text: p.name + ": " + reason });
  if (r.cohost === p.id) r.cohost = null;
  p.left = true;
  if (r.host === p.id) {
    p.seen = 0;
    assignHost(r, n);
  }
  if (win(r)) return;
  if (r.author === p.id && ["write", "countdown", "guess"].includes(r.phase)) {
    r.notice = p.name + " left; moving to the next presenter.";
    next(r, n);
  } else complete(r, n);
}
function tick(r, n = Date.now()) {
  assignHost(r, n);
  if (["lobby", "finished", "roundEnd", "reveal"].includes(r.phase)) return;
  if (win(r)) return;
  if (r.phase === "write" && n >= r.deadline) {
    r.notice = "Presenter timed out. Turn skipped.";
    next(r, n);
  } else if (r.phase === "countdown" && n >= r.deadline) {
    r.phase = "guess";
    r.guessStarted = r.deadline;
    r.deadline = r.guessStarted + r.settings.guessSeconds * 1e3;
    if (n >= r.deadline) reveal(r, n);
  } else if (r.phase === "guess" && n >= r.deadline) reveal(r, n);
}
function authenticate(r, b) {
  const p = r.members.find((p2) => p2.id === b.id && p2.secret === b.secret);
  if (!p) fail("Your room session ended. Please join again.");
  return p;
}
function act(r, b, n = Date.now()) {
  if (b.action === "join") {
    tick(r, n);
    if (r.manualLock || r.members.length >= 10) fail("Room is locked or full.");
    if (!safeName(b.name)) fail("Enter a nickname of 1\u201324 characters.");
    if (r.members.some((p3) => p3.name.toLowerCase() === b.name.trim().toLowerCase())) fail("That nickname is taken.");
    if (!["player", "viewer"].includes(b.role)) fail("Choose player or viewer.");
    if (b.role === "player" && r.phase !== "lobby") fail("Game in progress. Join as a viewer.");
    if (b.role === "player" && r.members.filter((p3) => p3.role === "player").length >= 8) fail("Eight players already joined. Choose viewer.");
    if (b.role === "viewer" && r.members.filter((p3) => p3.role === "viewer").length >= 2) fail("Both viewer seats are taken.");
    const p2 = member(b.name, b.role, n);
    r.members.push(p2);
    return { code: r.code, id: p2.id, secret: p2.secret };
  }
  const p = authenticate(r, b);
  p.seen = n;
  tick(r, n);
  const manage = () => {
    if (!manager(r, p)) fail("Host or co-host only.");
  };
  switch (b.action) {
    case "poll":
      break;
    case "ready":
      if (r.phase !== "lobby" || p.role !== "player") fail("Players can ready up in the lobby.");
      p.ready = !p.ready;
      break;
    case "settings":
      manage();
      if (r.phase !== "lobby") fail("Settings are locked during the game.");
      if (!Number.isInteger(b.points) || b.points < 3 || b.points > 6 || ![15, 30, 45, 60].includes(b.guessSeconds)) fail("Choose 3\u20136 starting points and an available timer.");
      r.settings = { points: b.points, guessSeconds: b.guessSeconds };
      r.members.forEach((m) => m.ready = false);
      break;
    case "lock":
      manage();
      r.manualLock = !r.manualLock;
      break;
    case "cohost":
      if (p.id !== r.host) fail("Only the host assigns a co-host.");
      if (b.target && (!r.members.some((m) => m.id === b.target) || b.target === r.host)) fail("Choose another room member.");
      r.cohost = b.target || null;
      break;
    case "request":
      if (p.role !== "viewer") fail("Only viewers request promotion.");
      p.requested = true;
      break;
    case "role":
      manage();
      if (r.phase !== "lobby") fail("Role changes apply before the next game.");
      {
        const t = r.members.find((m) => m.id === b.target);
        if (!t) fail("Member not found.");
        if (b.role === "player") {
          if (t.role === "viewer" && !t.requested) fail("This viewer must request promotion first.");
          if (t.role !== "player" && r.members.filter((m) => m.role === "player").length >= 8) fail("Player seats are full.");
        } else if (b.role === "viewer") {
          if (t.role !== "viewer" && r.members.filter((m) => m.role === "viewer").length >= 2) fail("Viewer seats are full.");
        } else fail("Invalid role.");
        t.role = b.role;
        t.ready = false;
        t.requested = false;
      }
      break;
    case "start":
      manage();
      if (r.phase !== "lobby") fail("The game already started.");
      {
        const ps = r.members.filter((m) => m.role === "player");
        if (ps.length < 2 || ps.some((m) => !m.ready || !connected(m, n) || m.away)) fail("At least two players must be connected, present, and ready.");
        for (const m of r.members) {
          m.score = m.role === "player" ? r.settings.points : 0;
          m.stats = stat();
          m.played = m.role === "player";
          m.awayRounds = 0;
        }
        r.round = 0;
        r.winner = null;
        r.notice = "";
        roundBegin(r, n);
      }
      break;
    case "submit":
      if (r.phase !== "write" || r.author !== p.id) fail("Only the current presenter can start guessing.");
      {
        const a = b.statements;
        if (!Array.isArray(a) || a.length !== 3 || a.some((s) => typeof s !== "string" || !s.trim() || s.length > 200)) fail("Enter three statements, up to 200 characters each.");
        const normalized = a.map((s) => s.trim().replace(/\s+/g, " ").toLowerCase());
        if (new Set(normalized).size !== 3) fail("Statements must be different.");
        r.statements = a.map((s) => s.trim());
        for (const m of r.members) r.orders[m.id] = shuffle([0, 1, 2]);
        r.eligible = active(r).filter((m) => m.id !== p.id && !m.away).map((m) => m.id);
        r.phase = "countdown";
        r.deadline = n + 3e3;
      }
      break;
    case "extend":
      if (r.phase !== "write" || r.author !== p.id || r.extended) fail("One extension per presenting turn.");
      r.deadline += 3e4;
      r.extended = true;
      r.notice = p.name + " requested 30 more seconds.";
      break;
    case "vote":
      if (r.phase !== "guess" || !r.eligible.includes(p.id) || p.away) fail("You cannot guess this turn.");
      if (Object.hasOwn(r.votes, p.id)) fail("Your answer is locked.");
      if (b.choice === null) {
        if (p.skips < 1) fail("No skips remaining. A timeout costs 1 point.");
        r.votes[p.id] = { choice: null };
      } else {
        if (!Number.isInteger(b.choice) || b.choice < 0 || b.choice > 2) fail("Choose a statement.");
        r.votes[p.id] = { choice: r.orders[p.id][b.choice], ms: Math.max(0, n - r.guessStarted) };
      }
      complete(r, n);
      break;
    case "next":
      manage();
      if (r.phase === "reveal") next(r, n);
      else if (r.phase === "roundEnd") roundBegin(r, n);
      else fail("Wait for the reveal.");
      break;
    case "restart":
      manage();
      if (r.phase !== "finished") fail("Wait until the game ends.");
      r.phase = "lobby";
      r.author = null;
      r.statements = [];
      r.results = [];
      r.votes = {};
      r.round = 0;
      r.winner = null;
      r.members.forEach((m) => {
        m.ready = false;
        m.away = false;
        m.awayRounds = 0;
        m.score = 0;
      });
      r.notice = "New game: review settings and ready up.";
      break;
    case "away":
      p.away = !p.away;
      if (!p.away) p.awayRounds = 0;
      if (p.away && r.author === p.id && r.phase === "write") next(r, n);
      break;
    case "leave":
      remove(r, p, n, "Left the room.");
      return { left: true };
    case "kick":
      manage();
      {
        const t = r.members.find((m) => m.id === b.target);
        if (!t || t.id === r.host || t.id === p.id) fail("Cannot remove this member.");
        remove(r, t, n, "Removed by a room manager.");
      }
      break;
    case "mute":
      manage();
      {
        const t = r.members.find((m) => m.id === b.target);
        if (!t || t.id === r.host || t.id === p.id) fail("Cannot mute this member.");
        t.muted = !t.muted;
      }
      break;
    case "chat":
      if (["guess", "countdown"].includes(r.phase)) fail("Chat is paused during guessing.");
      if (p.muted) fail("Your chat is muted.");
      if (typeof b.text !== "string" || !b.text.trim() || b.text.length > 200) fail("Messages must contain 1\u2013200 characters.");
      if (n - (p.lastChat ?? 0) < 2e3) fail("Wait 2 seconds between messages.");
      p.lastChat = n;
      r.chat.push({ id: uid(), name: p.name, text: b.text.trim() });
      r.chat = r.chat.slice(-80);
      break;
    case "react":
      if (!["reveal", "finished"].includes(r.phase)) fail("Reactions are available after the reveal.");
      if (!["\u{1F602}", "\u{1F62E}", "\u{1F44F}", "\u{1F525}", "\u2764\uFE0F", "\u{1F914}"].includes(b.emoji)) fail("Choose a reaction.");
      if (n - (p.lastReact ?? 0) < 2e3) fail("Wait 2 seconds between reactions.");
      p.lastReact = n;
      r.reactions.push({ id: uid(), name: p.name, emoji: b.emoji, at: n });
      r.reactions = r.reactions.slice(-20);
      break;
    default:
      fail("Unknown action.");
  }
  return { ok: true };
}
function view(r, p, n = Date.now()) {
  const avg = (m) => m.stats.correct ? m.stats.correctMs / m.stats.correct : null;
  const ranked = r.members.filter((m) => m.played).sort((a, b) => (b.id === r.winner) - (a.id === r.winner) || b.score - a.score || (avg(a) ?? Infinity) - (avg(b) ?? Infinity));
  let rank = 0, last;
  const rankings = ranked.map((m, i) => {
    const key = [m.id === r.winner, m.score, avg(m)].join("|");
    if (key !== last) rank = i + 1;
    last = key;
    return { id: m.id, name: m.name, rank, score: m.score, avgMs: avg(m), stats: m.stats };
  });
  const revealPhase = ["reveal", "finished"].includes(r.phase), order = r.orders[p.id] ?? [0, 1, 2];
  const v = r.votes[p.id];
  return { code: r.code, me: p.id, host: r.host, cohost: r.cohost, phase: r.phase, round: r.round, turnId: r.turnId, author: r.author, deadline: r.deadline, serverNow: n, settings: r.settings, manualLock: r.manualLock, locked: r.manualLock || r.members.length >= 10, playerFull: r.members.filter((m) => m.role === "player").length >= 8, notice: r.notice, extended: r.extended, winner: r.winner, rankings, members: r.members.map((m) => ({ id: m.id, name: m.name, role: m.role, score: m.score, ready: m.ready, away: m.away, awayRounds: m.awayRounds, online: connected(m, n), skips: m.skips, requested: m.requested, muted: m.muted })), statements: ["guess", "reveal", "finished"].includes(r.phase) ? order.map((i) => r.statements[i]) : [], myVote: v === void 0 ? void 0 : v.choice === null ? null : order.indexOf(v.choice), myResult: r.results.find((x) => x.id === p.id), lie: revealPhase ? order.indexOf(2) : void 0, lieText: revealPhase ? r.statements[2] : void 0, answered: Object.keys(r.votes).length, eligible: r.eligible?.length ?? 0, canGuess: r.phase === "guess" && r.eligible.includes(p.id) && !p.away && v === void 0, results: revealPhase ? r.results.map(({ id, type, delta }) => ({ id, type, delta })) : [], chat: ["guess", "countdown"].includes(r.phase) ? [] : r.chat, reactions: r.reactions.filter((x) => n - x.at < 15e3) };
}

// lib/netlify-handler.mjs
var headers = { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" };
var reply = (body, status = 200) => new Response(JSON.stringify(body), { status, headers });
var pause = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
function createHandler(storeFactory, clock = () => Date.now()) {
  return async function handle(request) {
    if (request.method !== "POST") return reply({ error: "Use POST." }, 405);
    const origin = request.headers.get("origin");
    if (origin && new URL(origin).origin !== new URL(request.url).origin) return reply({ error: "Invalid origin." }, 403);
    let body;
    try {
      const raw = await request.text();
      if (raw.length > 1e4) return reply({ error: "Request too large." }, 413);
      body = JSON.parse(raw);
      if (!body || typeof body !== "object" || Array.isArray(body)) throw Error();
    } catch {
      return reply({ error: "Invalid JSON request." }, 400);
    }
    try {
      const store = storeFactory();
      if (body.action === "create") {
        for (let attempt = 0; attempt < 10; attempt++) {
          const now = clock(), room = createRoom(body.name, body.role, now);
          const written = await store.setJSON(room.code, room, { onlyIfNew: true });
          if (written.modified === true && written.etag) {
            const player = room.members[0];
            return reply({ session: { code: room.code, id: player.id, secret: player.secret }, state: view(room, player, now) });
          }
        }
        return reply({ error: "Could not create a room. Please try again." }, 409);
      }
      const code = String(body.code ?? "").trim().toUpperCase();
      if (!/^[A-Z0-9]{6}$/.test(code)) return reply({ error: "Enter a six-character room code." }, 400);
      for (let attempt = 0; attempt < 16; attempt++) {
        const entry = await store.getWithMetadata(code, { type: "json", consistency: "strong" });
        if (!entry) return reply({ error: "Room not found." }, 404);
        if (!entry.etag) throw Error("Invalid storage response.");
        const room = entry.data, now = clock();
        let result;
        try {
          result = act(room, body, now);
        } catch (error) {
          return reply({ error: error.message }, 400);
        }
        const written = await store.setJSON(code, room, { onlyIfMatch: entry.etag });
        if (written.modified === true && written.etag) {
          if (result.left) return reply(result);
          const identity = body.action === "join" ? result : body;
          const player = authenticate(room, identity);
          return reply({ ...body.action === "join" ? { session: result } : {}, state: view(room, player, now) });
        }
        await pause(Math.min(5 * (attempt + 1), 40));
      }
      return reply({ error: "Room is busy. Please try again." }, 409);
    } catch (error) {
      if (/nickname|role/.test(error.message)) return reply({ error: error.message }, 400);
      return reply({ error: "Room service is unavailable. Please try again shortly." }, 503);
    }
  };
}

// netlify/functions/game.ts
var game_default = createHandler(() => getStore({
  name: "two-truths-and-a-lie-rooms",
  consistency: "strong"
}));
export {
  game_default as default
};
